<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection
$conn = new mysqli("localhost", "root", "", "aarogya_seva");

// Check if connection is successful
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// } else {
//     echo "Database connected successfully.<br>";
// }

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Retrieve form data
    
    $mobility = $_POST['mobility'] ?? '';
    $exertion = $_POST['exertion'] ?? '';
    $communication = $_POST['communication'] ?? '';
    $vision = $_POST['vision'] ?? '';
    $learning = $_POST['learning'] ?? '';
    $details = $_POST['details'] ?? '';

    // Verify the data is received
    echo "<pre>";
    print_r($_POST);  // Display the form data for debugging
    echo "</pre>";

    // Insert data into the database
    $sql = "INSERT INTO medical_form ( Mobility, physical_Exertion, Communication, Vision, Learning, ifyes_description1)
            VALUES ('$mobility', '$exertion', '$communication', '$vision', '$learning', '$details')";

    if ($conn->query($sql) === TRUE) {
        echo "Record inserted successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Declaration Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 50px;
      line-height: 1.6;
    }

    .container {
      border: 1px solid #000;
      padding: 20px;
      width: 90%;
      margin: 0 auto;
    }

    .title {
      text-align: center;
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 20px;
    }

    .content {
      text-align: justify;
    }

    .signatures {
      display: flex;
      justify-content: space-between;
      margin-top: 50px;
    }

    .sign-box {
      width: 40%;
    }

    .sign-box label {
      font-weight: bold;
    }

    .upload {
      margin-top: 10px;
    }

    .name-input {
      margin-top: 20px;
      width: 100%;
      border: 1px solid #000;
      padding: 5px;
      font-size: 1em;
    }

    .footer {
      text-align: center;
      margin-top: 30px;
      font-size: 0.9em;
    }

    .btn-row {
      display: flex;
      flex-direction: column;
      gap: 15px;
      margin-top: 30px;
    }

    .btn {
      padding: 10px;
      font-size: 1em;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      width: 100%;
      text-align: center;
    }

    .btn-back, .btn-save {
      background-color: #007bff;
      color: white;
    }

    .btn-submit {
      background-color: #28a745;
      color: white;
      margin-top: auto;
    }

    .btn-row-back-save {
      display: flex;
      justify-content: space-between;
      gap: 15px;
      margin-top: 30px;
    }

    .btn:hover {
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="container">
      <form action="HA_pg4.php" method="POST">
        <div class="title">घोषणा / DECLARATION</div>
        <div class="content">
          <p>
            We do hereby declare that the foregoing statement and answers have been given by us
            after fully understanding the questions, and the same are true and complete in every
            particular and that no information has been withheld. I understand that any willfully
            or misleading answer or material omission which relates to any question before mentioned
            may make me ineligible for my studies at Banasthali Vidyapith.
          </p>
          <p>
            हम यह स्पष्ट रूप से घोषणा करते हैं कि उपयुक्त विवरण तथा उत्तर हमारे द्वारा प्रश्नों को पूरी तरह समझने के बाद दिए गए हैं। 
            सभी विवरण सत्य एवं पूर्ण हैं और कोई जानकारी छिपाई नहीं गई है। मैं समझती/समझता हूँ कि पूछे गए किसी भी प्रश्न के 
            संबंध में मेरे द्वारा दिए गए गलत जवाब या मेरे द्वारा छिपाया गया तथ्य मुझे विद्यापीठ में अध्ययन करने के अयोग्य बना सकता है।
          </p>
        </div>
        <div class="signatures">
          <div class="sign-box">
            <label>Signature:</label>
            <input type="file" class="upload" accept="image/*" required>
            <p>Name of Guardian (in CAPITAL):</p>
            <input type="text" class="name-input" placeholder="Enter Guardian's Name" required>
          </div>
          <div class="sign-box">
            <label>Signature:</label>
            <input type="file" class="upload" accept="image/*" required>
            <p>Name of the Student:</p>
            <input type="text" class="name-input" placeholder="Enter Student's Name" required>
          </div>
        </div>
        <div class="btn-row-back-save">
          <button type="button" class="btn btn-back" onclick="window.history.back();">Back</button>
          <button type="submit" name="save" class="btn btn-save">Save as Draft</button>
        </div>
        <div class="btn-row">
          <button type="submit" name="submit" class="btn btn-submit">Submit</button>
        </div>
       </form>
  </div>
</body>
</html>
